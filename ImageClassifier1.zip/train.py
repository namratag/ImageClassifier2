import matplotlib.pyplot as plt
import numpy as np
import time
import torch
from torch import nn
from torch import tensor
from torch import optim
import torch.nn.functional as F
from torch.autograd import Variable
from torchvision import datasets, transforms
import torchvision.models as models
import argparse
import json
import utilfuncs

ap = argparse.ArgumentParser(description='Train.py')
# Command Line ardguments

ap.add_argument('data_dir', nargs='*', action="store", default="./flowers/")
ap.add_argument('--gpu', dest="gpu", action="store", default="gpu")
ap.add_argument('--save_dir', dest="save_dir", action="store", default="./checkpoint.pth")
ap.add_argument('--learning_rate', dest="learning_rate", action="store", default=0.001)
ap.add_argument('--dropout', dest = "dropout", action = "store", default = 0.5)
ap.add_argument('--epochs', dest="epochs", action="store", type=int, default=5)
ap.add_argument('--arch', dest="arch", action="store", default="densenet121", type = str)


pa = ap.parse_args()
path = pa.data_dir
spath = pa.save_dir
lr = pa.learning_rate
structure = pa.arch
dropout = pa.dropout

power = pa.gpu
epochs = pa.epochs
print(structure)

trainloader, validloader, testloader,train_data = utilfuncs.load_data(path)


model, criterion, optimizer = utilfuncs.model_setup(structure,dropout,512,128,0,lr,power)

model = utilfuncs.train_network(model, optimizer, criterion, trainloader,validloader, epochs, 10, power)


utilfuncs.check_accuracy_on_test(model,testloader)

with open('cat_to_name.json', 'r') as json_file:
    cat_to_name = json.load(json_file)
path_image = '/home/workspace/ImageClassifier/flowers/test/1/image_06743.jpg'
print(path_image)
probabilities = utilfuncs.predict(path_image, model, 5, power)


labels = [cat_to_name[str(index + 1)] for index in np.array(probabilities[1][0])]
probability = np.array(probabilities[0][0])


i=0
while i < 5:
    print("{} with a probability of {}".format(labels[i], probability[i]))
    i += 1
utilfuncs.save_checkpoint(model,train_data, spath,structure,512,128,0,dropout,lr)    
print("Model Trained")